# NetCDF Viewer QGIS Plugin

A QGIS plugin for loading and visualizing NetCDF (.nc) files with dimension browsing capabilities.

## Features

- Load NetCDF (.nc) files
- Browse dimensions and variables
- Interactive dimension selection
- Customizable visualization options

## Installation

1. Install required dependencies:
```bash
pip install -r requirements.txt
```

2. Copy the plugin folder to your QGIS plugins directory:
   - Windows: `C:\Users\{username}\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins`
   - Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins`
   - macOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins`

3. Enable the plugin in QGIS:
   - Open QGIS
   - Go to Plugins > Manage and Install Plugins
   - Find "NetCDF Viewer" in the list
   - Check the box to enable it

## Usage

1. Click the NetCDF Viewer icon in the QGIS toolbar
2. Select a .nc file to load
3. Browse through the available dimensions and variables
4. Select visualization parameters
5. Click "Visualize" to display the data on the map

## Requirements

- QGIS 3.0 or later
- Python packages listed in requirements.txt
